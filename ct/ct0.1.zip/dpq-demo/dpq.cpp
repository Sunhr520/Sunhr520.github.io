#include<cstdio>
#include<cstdlib>
#include<ctime>

using namespace std;

int main()
{   int s,t;
    system("cls");
    int T = 1e3;
    while(T--)
	{
        system("data.exe >data.in"); //data���������ɳ���
        s=clock();
        system("my.exe <data.in >my.out");  //myҪ���ĳ���
        t=clock();
        system("violence.exe <data.in >violence.out");  //violence��ȷ�ĳ���
        
		//if(system("fc my.out violence.out"))
		if(system("fc my.out violence.out >nul"))
            break;
        else printf("AC time: %d ms\n",t-s);
    }
    system("fc my.out violence.out");
    printf("WA time: %dms\n",t-s);  //����ʱ�� 
	
    return 0;
}
