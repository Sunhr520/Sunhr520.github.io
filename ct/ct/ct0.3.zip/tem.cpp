//#pragma GCC optimize(2) 
//#pragma GCC optimize(3)

#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<cmath>
#include<vector>
#include<map>
using namespace std;

#define in(x) (x) = read()
#define inn(x, y) in(x),in(y)
#define innn(x, y, z) inn(x, y),in(z)
#define innnn(x, y, z, w) inn(x, y),inn(z, w)
#define fre(x) for(int _=1; _<=(x);_++)
#define free(x, y) for(int _=1;_<=(x);_++)for(int __=1;__<=(y);__++)
#define frein() int in(Loop_var);while(Loop_var--)

//#define int long long
//#define int __int128

typedef pair<int, int> pii;
#define fi first
#define se second
typedef pair<int, pair<int, int> > piii;
#define fir first
#define sec second.first
#define thi second.second

inline int read()
{
	int ans = 0, mark = 1;
	int t = getchar();
	while(t < '0' || t > '9')
	{
		if (t == '-')
			mark = -1;
		t = getchar();
	}
	while(t <= '9' && t >= '0')
	{
		ans = (ans << 3) + (ans << 1) + t - '0';
		t = getchar();
	}

	return ans * mark;	
}
int gcd(int a, int b) { return b ? gcd(b, a % b) : a;}
int qmi(int a,int b,int p)
{
    int res = 1;
    while(b)
    {
        if(b&1) res = (res*a)%p;
        a = a*a%p;
        b >>= 1;
    }
    return res;
}

const int INF = 0x3f3f3f3f;
const int N = 1e5+5, p = 998244353;

signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	//IO

	//cout << "Hello World!" << endl;
    
	return 0;
}

//
//                       _oo0oo_
//                      o8888888o
//                      88" . "88
//                      (| -_- |)
//                      0\  =  /0
//                    ___/`---'\___
//                  .' \\|     |// '.
//                 / \\|||  :  |||// \
//                / _||||| -:- |||||- \
//               |   | \\\  -  /// |   |
//               | \_|  ''\---/''  |_/ |
//               \  .-\__  '-'  ___/-. /
//             ___'. .'  /--.--\  `. .'___
//          ."" '<  `.___\_<|>_/___.' >' "".
//         | | :  `- \`.;`\ _ /`;.`/ - ` : | |
//         \  \ `_.   \_ __\ /__ _/   .-` /  /
//     =====`-.____`.___ \_____/___.-`___.-'=====
//                       `=---='






