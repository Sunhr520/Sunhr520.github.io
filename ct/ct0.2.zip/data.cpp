#include<iostream>
#include<cstdlib>
#include<ctime>
#include<vector>
using namespace std;

const long long  N = 1e5;
const int M = 1e9;
int book[N];

int main()
{
	srand((unsigned)time(NULL));
	
	
		
	return 0;
	
} 
